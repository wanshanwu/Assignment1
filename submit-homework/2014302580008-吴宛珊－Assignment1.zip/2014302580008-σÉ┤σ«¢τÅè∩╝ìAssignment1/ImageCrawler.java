import java.io.File;
public class ImageCrawler {
	public static void main(String[] args) {
		String url = "http://210.42.121.241/servlet/Svlt_QueryStuScore?year=0&term=&learnType=&scoreFlag=0&t=Tue%20Sep%2022%202015%2011:37:46%20GMT+0800%20(CST)";
		for(int counter=0;counter<=5;counter++){
			//抓取成绩url和Cookie
			HttpRequest response = HttpRequest.get(url).header("Cookie","JSESSIONID=826402D7173E08FCA447CF52E5A13B70.tomcat2");
			//文件命名
			String fName = "score"+Integer.toString(counter)+".html";
			if(response.ok()){
				response.receive(new File(fName));
			}
		}
	
	}

}